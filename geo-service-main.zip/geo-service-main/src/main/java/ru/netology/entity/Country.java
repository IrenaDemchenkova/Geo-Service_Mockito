package ru.netology.entity;

public enum Country {
    RUSSIA,
    GERMANY,
    USA,
    BRAZIL;
}
